from django.db import models
from django.contrib.auth.models import User


class Customer(models.Model):
	user = models.OneToOneField(User, null=True, blank=True, on_delete=models.CASCADE)
	name = models.CharField(max_length=200, null=True)
	email = models.CharField(max_length=200, null=True)
	points= models.IntegerField(default=0)
	def __str__(self):
		return self.name

		
class report(models.Model):
	STATUS = (
			('Unknown', 'Unknown'),
			('Free', 'Free'),
			('Occupied', 'Occupied'),
			)
	Location = (
			('A1', 'A1'),
			('A2', 'A2'),
			('A3', 'A3'),
			('A4', 'A4'),
			('A5', 'A5'),
			('A6', 'A6'),
			('A7', 'A7'),
			('A8', 'A8'),
			('A9', 'A9'),
			('A10', 'A10'),
			('A11', 'A11'),
			('A12', 'A12'),
			('A13', 'A13'),
			('A14', 'A14'),
			('A15', 'A15'),
			)

	user = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
	date_created = models.DateTimeField(auto_now_add=True, null=True)
	status = models.CharField(max_length=200, null=True, choices=STATUS, default= 'Unknown')
	location = models.CharField(max_length=200, null=True, choices=Location, default= 'A1')
	
	def __str__(self):
		return self.location
