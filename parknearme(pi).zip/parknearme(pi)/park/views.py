from django.shortcuts import render, redirect
import pyrebase
from django.contrib.auth.models import Group
from .decorators import allowed_users
from django.forms import inlineformset_factory
from .forms import CreateUserForm, CreateReportForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import *

config = {
    "apiKey": "AIzaSyDPuKnZ_W7X_NgcoTlGnzTMWI6ujl2rKyg",
    "authDomain": "parking-system-365621.firebaseapp.com",
    "databaseURL": "https://parking-system-365621-default-rtdb.firebaseio.com",
    "projectId": "parking-system-365621",
    "storageBucket": "parking-system-365621.appspot.com",
    "messagingSenderId": "514457351378",
    "appId": "1:514457351378:web:fd8054194b6cacd0d9e90b",
}
firebase = pyrebase.initialize_app(config)
authe = firebase.auth()
database = firebase.database()

###  Main Nav  ###

def home(request):
    array = database.child('occupancy').get().val()
    slot = []
    state = []
    occupied = 0
    free = 0
    total_space = 0
    for i in range(len(array)):
        if array[i]['state'] == "occupied":
            occupied += 1
        else:
            free += 1
        state.append(array[i]['state'])
        slot.append((array[i]['slot']))
        total_space = i + 1

    print(state)
    print(slot)
    print(free)
    print(occupied)
    print("this is ", free)
    

    context = {'free': free, 'occupied': occupied, 'total_space': total_space}
    return render(request, 'park/home.html',context)

def AboutUs(request):
    return render(request, 'park/AboutUs.html')



def dashboard(request):
    array = database.child('occupancy').get().val()
    slot = []
    state = []
    occupied = 0
    free = 0
    total_space = 0
    for i in range(len(array)):
        if array[i]['state'] == "occupied":
            occupied += 1
        else:
            free += 1
        state.append(array[i]['state'])
        slot.append((array[i]['slot']))
        total_space = i+1

    print(state)
    print(slot)
    print(free)
    print(occupied)
    print("this is ", free)
    user=request.user
    customer=Customer.objects.get(user=user)
    points=customer.points
    context = {'free':free, 'occupied':occupied,'total_space':total_space,'points':points}
    return render(request,'park/Dashboard.html',context)


####  locations ###
def Location1(request):
    a = database.child('occupancy').get().val()
    slot = []
    state = []
    occupied = 0
    free = 0
    total_space = 0
    for i in range(len(a)):
        if a[i]['state'] == "occupied":
            occupied += 1
        else:
            free += 1
        state.append(a[i]['state'])
        slot.append((a[i]['slot']))
        total_space = i + 1

    context = {'state':state, 'slot':slot, 'free': free, 'occupied': occupied, 'total_space': total_space}

    return render(request, "park/Location1.html", context)


def Report(request):
    Report=report.objects.all()
    free=report.objects.filter(status='Free')
    user=request.user
    customer=Customer.objects.get(user=user)
    print(customer.name)
    Free_num=0
    for i in free:
        Free_num+=1
    Total_num=15
    Occupied_num=Total_num-Free_num
    

    
    num=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    form=CreateReportForm(initial={'user':user}) 

    if request.method=='POST':
        form=CreateReportForm(request.POST)
        if form.is_valid():
            form.save()
            customer.points= customer.points + 1
            print(customer.points)
            customer.save()
            return redirect('Report')
        else:
            print("not valid")    

    context={'num':num,'report':Report,'form':form,'Free_num':Free_num,'Occupied_num':Occupied_num,'Total_num':Total_num}
    return render(request, 'park/Report.html',context)


def Reserve(request):
    return render(request, 'park/Reserve.html')

def Vid(request):
    return render(request,'park/vid.html')


###Account###
def Register(request):
    form=CreateUserForm()
    if request.method=="POST":
        form=CreateUserForm(request.POST)
        if form.is_valid():
            user=form.save()
            group= Group.objects.get(name='customer')
            user.groups.add(group)
            username=form.cleaned_data.get('username')
            email=form.cleaned_data.get('email')
            Customer.objects.create(
                user=user,
                name=username,
                email=email
                )

            messages.success(request, 'Account was Created for '+username)
            return redirect('login')
    context={'form':form}
    return render(request,'park/register.html',context)

def Login(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.info(request,'Username or Password is incorrect')
            
    context={}
    return render(request, 'park/login.html', context)

def Logout(request):
    logout(request)
    return redirect('login')