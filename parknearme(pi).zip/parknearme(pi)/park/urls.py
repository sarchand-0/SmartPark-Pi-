from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
urlpatterns=[
	path('',views.home, name="home"),
    path('Dashboard/',views.dashboard, name="dash"),
    path('Location1/',views.Location1, name="loc1"),
    path('AboutUs/',views.AboutUs, name="AboutUs"),
    path('Reserve/',views.Reserve, name="Reserve"),
    path('Report/',views.Report, name="Report"),
    path('Vid/',views.Vid,name='vid'),

    


    path('register/',views.Register, name="register"),
    path('login/',views.Login, name="login"),
    path('logout/',views.Logout, name="logout"),
    ]